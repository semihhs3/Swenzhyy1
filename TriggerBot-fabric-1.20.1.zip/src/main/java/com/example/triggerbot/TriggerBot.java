package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;

public final class TriggerBot {
    private static long readySince = 0;

    private TriggerBot() {}

    public static boolean canCrit(ClientPlayerEntity p) {
        return p.fallDistance > 0.0F
                && !p.isOnGround()
                && !p.isClimbing()
                && !p.isTouchingWater()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS)
                && !p.hasVehicle();
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I;
        ClientPlayerEntity p = mc.player;
        if (!c.triggerEnabled || p == null || mc.world == null || mc.interactionManager == null
                || mc.currentScreen != null || c.prehitEnabled) {
            readySince = 0;
            return;
        }

        Entity target = Targets.underCrosshair(mc, c.playersOnly);
        boolean ready = target != null
                && p.getAttackCooldownProgress(0.5F) >= 0.92F
                && (!c.critOnly || canCrit(p));

        if (!ready) {
            readySince = 0;
            return;
        }

        long now = System.currentTimeMillis();
        if (readySince == 0) readySince = now;
        if (now - readySince < c.triggerDelay) return;

        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
        readySince = 0;
    }
}
