package com.example.triggerbot.gui;

import com.example.triggerbot.Config;
import com.example.triggerbot.TriggerBotClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class ClickGuiScreen extends Screen {
    private static final int ACCENT = 0x8B6CFF;
    private static final int ACCENT_LIGHT = 0xCFC4FF;
    private static final int GREEN = 0x4ADE80;

    private final List<Panel> panels = new ArrayList<>();
    private float openAnim = 0f;
    private long last = System.nanoTime();
    private Row dragging;
    private int maxH, topY;

    public ClickGuiScreen() {
        super(Text.literal("TriggerBot"));
    }

    // ---------- helpers ----------
    private static float approach(float cur, float tgt, float dt, float speed) {
        return cur + (tgt - cur) * (1f - (float) Math.exp(-speed * dt));
    }

    private static float clamp01(float v) {
        return v < 0 ? 0 : Math.min(v, 1f);
    }

    private static float ease(float t) {
        float i = 1f - clamp01(t);
        return 1f - i * i * i;
    }

    private static int col(float alpha, int rgb) {
        int a = (int) (clamp01(alpha) * 255f);
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    private static int mix(int c1, int c2, float t) {
        int r = 0;
        for (int s = 0; s <= 24; s += 8) {
            int a = (c1 >> s) & 0xFF, b = (c2 >> s) & 0xFF;
            r |= (((int) (a + (b - a) * t)) & 0xFF) << s;
        }
        return r;
    }

    private static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    private void txt(DrawContext c, String s, int x, int y, int rgb, float alpha) {
        if (alpha < 0.03f) return;
        c.drawText(textRenderer, s, x, y, col(alpha, rgb), false);
    }

    // ---------- rows ----------
    private abstract class Row {
        int x, y, w;
        float hover;

        abstract int height();

        abstract void render(DrawContext c, int mx, int my, float dt, float a);

        boolean click(double mx, double my) {
            return false;
        }

        void drag(double mx) {
        }

        boolean inside(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + height();
        }

        void updateHover(int mx, int my, float dt) {
            hover = approach(hover, inside(mx, my) ? 1f : 0f, dt, 14f);
        }
    }

    private class Toggle extends Row {
        final String label;
        final BooleanSupplier get;
        final Consumer<Boolean> set;
        float t = -1;

        Toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
            this.label = label;
            this.get = get;
            this.set = set;
        }

        int height() {
            return 24;
        }

        void render(DrawContext c, int mx, int my, float dt, float a) {
            updateHover(mx, my, dt);
            float target = get.getAsBoolean() ? 1f : 0f;
            if (t < 0) t = target;
            t = approach(t, target, dt, 16f);

            rrect(c, x, y + 1, w, 22, 5, col(a * hover * 0.09f, 0xFFFFFF));
            txt(c, label, x + 6, y + 8, 0xFFFFFF, a * (0.72f + 0.28f * t));

            int sw = 26, sh = 12, sx = x + w - sw - 6, sy = y + 6;
            rrect(c, sx, sy, sw, sh, 6, mix(col(a, 0x3A3A4E), col(a, ACCENT), t));
            int kx = sx + 2 + Math.round(t * (sw - sh));
            rrect(c, kx, sy + 2, sh - 4, sh - 4, 4, col(a, 0xFFFFFF));
        }

        boolean click(double mx, double my) {
            if (!inside(mx, my)) return false;
            set.accept(!get.getAsBoolean());
            return true;
        }
    }

    private class Cycle extends Row {
        final String label;
        final Supplier<String> get;
        final Runnable action;

        Cycle(String label, Supplier<String> get, Runnable action) {
            this.label = label;
            this.get = get;
            this.action = action;
        }

        int height() {
            return 24;
        }

        void render(DrawContext c, int mx, int my, float dt, float a) {
            updateHover(mx, my, dt);
            rrect(c, x, y + 1, w, 22, 5, col(a * hover * 0.09f, 0xFFFFFF));
            txt(c, label, x + 6, y + 8, 0xFFFFFF, a * 0.8f);

            String v = get.get();
            int pw = textRenderer.getWidth(v) + 14;
            int px = x + w - pw - 6;
            rrect(c, px, y + 4, pw, 16, 8, col(a * (0.28f + 0.2f * hover), ACCENT));
            txt(c, v, px + 7, y + 8, ACCENT_LIGHT, a);
        }

        boolean click(double mx, double my) {
            if (!inside(mx, my)) return false;
            action.run();
            return true;
        }
    }

    private class Slider extends Row {
        final String label;
        final int min, max, step;
        final Function<Integer, String> fmt;
        final IntSupplier get;
        final IntConsumer set;
        float fill = -1;

        Slider(String label, int min, int max, int step, Function<Integer, String> fmt,
               IntSupplier get, IntConsumer set) {
            this.label = label;
            this.min = min;
            this.max = max;
            this.step = step;
            this.fmt = fmt;
            this.get = get;
            this.set = set;
        }

        int height() {
            return 30;
        }

        void render(DrawContext c, int mx, int my, float dt, float a) {
            updateHover(mx, my, dt);
            float frac = (get.getAsInt() - min) / (float) (max - min);
            if (fill < 0) fill = frac;
            fill = approach(fill, frac, dt, 18f);

            txt(c, label, x + 6, y + 4, 0xFFFFFF, a * 0.8f);
            String v = fmt.apply(get.getAsInt());
            txt(c, v, x + w - 6 - textRenderer.getWidth(v), y + 4, ACCENT_LIGHT, a);

            int tx = x + 6, tw = w - 12, ty = y + 19;
            rrect(c, tx, ty, tw, 4, 2, col(a, 0x2A2A3C));
            rrect(c, tx, ty, Math.max(4, Math.round(tw * fill)), 4, 2, col(a, ACCENT));
            int ks = dragging == this ? 10 : 8;
            int kx = tx + Math.round((tw - ks) * fill);
            rrect(c, kx, ty + 2 - ks / 2, ks, ks, ks / 2, col(a, 0xFFFFFF));
        }

        boolean click(double mx, double my) {
            if (!inside(mx, my)) return false;
            dragging = this;
            drag(mx);
            return true;
        }

        void drag(double mx) {
            float f = clamp01((float) ((mx - (x + 6)) / (w - 12)));
            int v = min + Math.round(f * (max - min) / step) * step;
            set.accept(Math.max(min, Math.min(max, v)));
        }
    }

    // ---------- panel ----------
    private class Panel {
        final String title, sub;
        final BooleanSupplier on;
        final List<Row> rows = new ArrayList<>();
        int x, y, w, h;
        float glow;

        Panel(String title, String sub, BooleanSupplier on) {
            this.title = title;
            this.sub = sub;
            this.on = on;
        }

        Panel add(Row r) {
            rows.add(r);
            return this;
        }

        void layout(int x, int y, int w) {
            this.x = x;
            this.y = y;
            this.w = w;
            int cy = y + 36;
            for (Row r : rows) {
                r.x = x + 6;
                r.y = cy;
                r.w = w - 12;
                cy += r.height();
            }
            h = cy - y + 6;
        }

        void render(DrawContext c, int mx, int my, float dt, float prog) {
            float a = ease(prog);
            if (a <= 0.01f) return;
            glow = approach(glow, on.getAsBoolean() ? 1f : 0f, dt, 10f);

            c.getMatrices().push();
            c.getMatrices().translate(0f, (1f - a) * 16f, 0f);

            rrect(c, x - 1, y - 1, w + 2, h + 2, 8, col(a * (0.3f + 0.6f * glow), mix(0x3A3A4E, ACCENT, glow)));
            rrect(c, x, y, w, h, 7, col(a * 0.95f, 0x12121C));

            txt(c, title, x + 10, y + 9, 0xFFFFFF, a);
            txt(c, sub, x + 10, y + 20, 0x8A8AA0, a);
            rrect(c, x + w - 16, y + 12, 6, 6, 3, col(a, mix(0x4A4A5E, GREEN, glow)));
            c.fill(x + 8, y + 32, x + w - 8, y + 33, col(a * 0.1f, 0xFFFFFF));

            for (Row r : rows) r.render(c, mx, my, dt, a);

            c.getMatrices().pop();
        }
    }

    // ---------- screen ----------
    @Override
    protected void init() {
        panels.clear();
        Config c = Config.I;

        Panel trig = new Panel("Trigger Bot", "Auto attack", () -> c.triggerEnabled);
        trig.add(new Toggle("Enabled", () -> c.triggerEnabled, v -> c.triggerEnabled = v));
        trig.add(new Cycle("Mode", () -> c.critOnly ? "Crit" : "Normal", () -> c.critOnly = !c.critOnly));
        trig.add(new Slider("Delay", 0, 500, 5, v -> v + " ms", () -> c.triggerDelay, v -> c.triggerDelay = v));
        trig.add(new Toggle("Players only", () -> c.playersOnly, v -> c.playersOnly = v));

        Panel pre = new Panel("Prehit", "Slot swap + hit", () -> c.prehitEnabled);
        pre.add(new Toggle("Enabled", () -> c.prehitEnabled, v -> c.prehitEnabled = v));
        pre.add(new Slider("Weapon slot", 1, 9, 1, v -> "Slot " + v, () -> c.prehitWeaponSlot, v -> c.prehitWeaponSlot = v));
        pre.add(new Slider("Firework slot", 1, 9, 1, v -> "Slot " + v, () -> c.prehitFireworkSlot, v -> c.prehitFireworkSlot = v));
        pre.add(new Slider("Delay", 0, 500, 5, v -> v + " ms", () -> c.prehitDelay, v -> c.prehitDelay = v));
        pre.add(new Toggle("Wait cooldown", () -> c.prehitWaitCooldown, v -> c.prehitWaitCooldown = v));

        Panel spr = new Panel("Sprint", "Auto sprint on W", () -> c.sprintEnabled);
        spr.add(new Toggle("Enabled", () -> c.sprintEnabled, v -> c.sprintEnabled = v));

        panels.add(trig);
        panels.add(pre);
        panels.add(spr);

        int pw = Math.min(142, (width - 40) / 3);
        int gap = 10;
        int total = pw * 3 + gap * 2;
        int x0 = (width - total) / 2;
        maxH = 0;
        for (Panel p : panels) {
            p.layout(0, 0, pw);
            maxH = Math.max(maxH, p.h);
        }
        topY = (height - maxH) / 2 + 8;
        for (int i = 0; i < panels.size(); i++) {
            panels.get(i).layout(x0 + i * (pw + gap), topY, pw);
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1_000_000_000f);
        last = now;
        openAnim = Math.min(1f, openAnim + dt / 0.55f);

        float bg = ease(openAnim);
        ctx.fill(0, 0, width, height, col(bg * 0.6f, 0x06060C));

        // title
        ctx.getMatrices().push();
        ctx.getMatrices().translate(width / 2f, topY - 30f + (1f - bg) * -8f, 0f);
        ctx.getMatrices().scale(1.6f, 1.6f, 1f);
        if (bg > 0.05f) {
            ctx.drawCenteredTextWithShadow(textRenderer, "TRIGGERBOT", 0, 0, col(bg, ACCENT_LIGHT));
        }
        ctx.getMatrices().pop();

        for (int i = 0; i < panels.size(); i++) {
            float prog = clamp01(openAnim * 1.7f - i * 0.22f);
            panels.get(i).render(ctx, mx, my, dt, prog);
        }

        String hint = TriggerBotClient.guiKey.getBoundKeyLocalizedText().getString() + ": close   |   "
                + TriggerBotClient.prehitKey.getBoundKeyLocalizedText().getString() + ": prehit";
        ctx.drawCenteredTextWithShadow(textRenderer, hint, width / 2, topY + maxH + 12, col(bg * 0.55f, 0xFFFFFF));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && openAnim > 0.5f) {
            for (Panel p : panels) {
                for (Row r : p.rows) {
                    if (r.click(mx, my)) return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null && button == 0) {
            dragging.drag(mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            dragging = null;
            Config.save();
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (TriggerBotClient.guiKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        Config.save();
    }
}
