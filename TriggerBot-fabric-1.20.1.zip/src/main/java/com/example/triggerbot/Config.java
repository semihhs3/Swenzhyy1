package com.example.triggerbot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class Config {
    public static Config I = new Config();

    // Trigger bot
    public boolean triggerEnabled = false;
    public boolean critOnly = true;
    public boolean playersOnly = true;
    public int triggerDelay = 0; // ms

    // Prehit
    public transient boolean prehitEnabled = false;
    public int prehitWeaponSlot = 1;   // 1-9
    public int prehitFireworkSlot = 2; // 1-9
    public int prehitDelay = 0;        // ms
    public boolean prehitWaitCooldown = true;

    // Sprint
    public boolean sprintEnabled = false;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("triggerbot.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                try (Reader r = Files.newBufferedReader(f)) {
                    Config c = GSON.fromJson(r, Config.class);
                    if (c != null) I = c;
                }
            }
        } catch (Exception ignored) {
        }
        I.clamp();
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(file())) {
            GSON.toJson(I, w);
        } catch (IOException ignored) {
        }
    }

    private void clamp() {
        triggerDelay = Math.max(0, Math.min(500, triggerDelay));
        prehitDelay = Math.max(0, Math.min(500, prehitDelay));
        prehitWeaponSlot = Math.max(1, Math.min(9, prehitWeaponSlot));
        prehitFireworkSlot = Math.max(1, Math.min(9, prehitFireworkSlot));
    }
}
