package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;

public final class Prehit {
    private static boolean wasEnabled = false;
    private static long readySince = 0;

    private Prehit() {}

    public static void tick(MinecraftClient mc) {
        Config c = Config.I;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) {
            wasEnabled = false;
            readySince = 0;
            return;
        }
        if (!c.prehitEnabled) {
            wasEnabled = false;
            readySince = 0;
            return;
        }

        int weapon = c.prehitWeaponSlot - 1;

        // Just activated: go to the chosen slot.
        if (!wasEnabled) {
            wasEnabled = true;
            readySince = 0;
            p.getInventory().selectedSlot = weapon;
        }

        if (mc.currentScreen != null) return;
        if (p.getInventory().selectedSlot != weapon) {
            readySince = 0;
            return;
        }

        Entity target = Targets.underCrosshair(mc, false);
        boolean ready = target != null
                && (!c.prehitWaitCooldown || p.getAttackCooldownProgress(0.5F) >= 0.92F);

        if (!ready) {
            readySince = 0;
            return;
        }

        long now = System.currentTimeMillis();
        if (readySince == 0) readySince = now;
        if (now - readySince < c.prehitDelay) return;

        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);

        // After the hit: switch to the firework slot and disarm.
        p.getInventory().selectedSlot = c.prehitFireworkSlot - 1;
        c.prehitEnabled = false;
        wasEnabled = false;
        readySince = 0;
    }
}
