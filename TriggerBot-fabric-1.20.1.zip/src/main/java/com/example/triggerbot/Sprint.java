package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

public final class Sprint {
    private static boolean forced = false;

    private Sprint() {}

    public static void tick(MinecraftClient mc) {
        if (mc.player == null) {
            forced = false;
            return;
        }
        KeyBinding sprintKey = mc.options.sprintKey;
        if (!Config.I.sprintEnabled) {
            if (forced) {
                sprintKey.setPressed(false);
                forced = false;
            }
            return;
        }
        if (mc.options.forwardKey.isPressed()) {
            sprintKey.setPressed(true);
            forced = true;
        } else if (forced) {
            sprintKey.setPressed(false);
            forced = false;
        }
    }
}
