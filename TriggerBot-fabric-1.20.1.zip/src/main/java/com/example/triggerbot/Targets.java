package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;

public final class Targets {
    private Targets() {}

    /** Entity currently under the crosshair, or null if not a valid target. */
    public static Entity underCrosshair(MinecraftClient mc, boolean playersOnly) {
        if (mc.player == null) return null;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return null;
        Entity t = hit.getEntity();
        if (t == mc.player) return null;
        if (!(t instanceof LivingEntity le) || !le.isAlive() || t.isSpectator()) return null;
        if (t instanceof ArmorStandEntity) return null;
        if (playersOnly && !(t instanceof PlayerEntity)) return null;
        return t;
    }
}
