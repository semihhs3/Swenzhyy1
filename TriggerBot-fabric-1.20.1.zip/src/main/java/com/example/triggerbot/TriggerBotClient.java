package com.example.triggerbot;

import com.example.triggerbot.gui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class TriggerBotClient implements ClientModInitializer {
    public static KeyBinding guiKey;
    public static KeyBinding prehitKey;

    @Override
    public void onInitializeClient() {
        Config.load();

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.triggerbot"));
        prehitKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.prehit", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.triggerbot"));

        ClientTickEvents.START_CLIENT_TICK.register(Sprint::tick);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (guiKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new ClickGuiScreen());
            }
            while (prehitKey.wasPressed()) {
                if (mc.player != null && mc.currentScreen == null) {
                    Config.I.prehitEnabled = !Config.I.prehitEnabled;
                    mc.inGameHud.setOverlayMessage(
                            Text.literal("Prehit: " + (Config.I.prehitEnabled ? "ON" : "OFF")), false);
                }
            }
            TriggerBot.tick(mc);
            Prehit.tick(mc);
        });
    }
}
