# TriggerBot (Fabric 1.20.1)

- **Trigger Bot**: crosshair bir canlının üzerindeyken otomatik vurur. Delay (ms), Crit / Normal modu, sadece oyuncular.
- **Prehit**: açınca seçtiğin slota geçer, o itemle hitbox'a bakınca (delay sonrası) vurur, sonra firework slotuna geçer ve kendini kapatır.
- **Sprint**: W'ye basınca otomatik sprint.

Tuşlar: `Right Shift` = GUI, `V` = Prehit aç/kapat (Controls menüsünden değişir).

## Derleme
GitHub'a yükle -> Actions sekmesi -> `build` -> Artifacts -> `TriggerBot` (jar içinde).
Lokalde: `gradle build` (Gradle 8.5+, Java 17) -> `build/libs/triggerbot-1.0.0.jar`.
Gerekli: Fabric Loader 0.15+ ve Fabric API.
